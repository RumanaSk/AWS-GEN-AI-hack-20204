import json
import uuid
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Anomaly_detection_awshack')

def get_named_parameter(event, name):
    """
    Get a parameter from the lambda event
    """
    return next(item for item in event['parameters'] if item['name'] == name)['value']



def create_Anomaly_solution(SupplierName, Anomaly_detected, Anomaly_solution):
    """
    Create a new Anomaly_solution entry
    
    Args:
        
        SupplierName (string):Name of the supplier
        Anomaly_detected (string): The anomaly that is interpreted in tha particular suppliers deliveries
        Anomaly_solution (integer): Basic solutoons to hoe to avoid the anomalies the next time based on other data
    """
    try:
         SupplierID = str(uuid.uuid4())[:8]
        table.put_item(
            Item={
                'SupplierID':  SupplierID,
                'SupplierName': SupplierName,
                'Anomaly_detected': Anomaly_detected,
                'Anomaly_solution': Anomaly_solution
            }
        )
        return {' SupplierID':  SupplierID}
    except Exception as e:
        return {'error': str(e)}



def lambda_handler(event, context):
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = event.get('parameters', [])


    if function == 'create_Anomaly_solution':
        SupplierName = get_named_parameter(event, "SupplierName")
        Anomaly_detected = get_named_parameter(event, "Anomaly_detected")
        Anomaly_solution = get_named_parameter(event, "Anomaly_solution")
        

        if SupplierName and Anomaly_detected and Anomaly_solution:
            response = str(create_Anomaly_solution(SupplierName, Anomaly_detected, Anomaly_solution))
            responseBody = {'TEXT': {'body': json.dumps(response)}}
        else:
            responseBody = {'TEXT': {'body': 'Missing required parameters'}}
        else:
            responseBody = {'TEXT': {'body': 'Invalid function'}}


    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response
