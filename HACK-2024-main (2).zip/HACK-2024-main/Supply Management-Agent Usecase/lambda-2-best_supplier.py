import json
import uuid
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Best-supplier-table')

def get_named_parameter(event, name):
    """
    Get a parameter from the lambda event
    """
    return next(item for item in event['parameters'] if item['name'] == name)['value']



def create_recommendation(SupplierName, Product_name, Reason_for_choice):
    """
    Create a new recommendation entry
    
    Args:
        
        SupplierName (string):Name of the supplier
        Product_name (string): TThe name of the product
        Reason_for_choice (string): The reason to recommend that supplier
    """
    try:
        SupplierID = str(uuid.uuid4())[:8]
        table.put_item(
            Item={
                'SupplierID': CustomerID,
                'SupplierName': SupplierName,
                'Product_name': Product_name,
                'Reason_for_choice': Reason_for_choice
            }
        )
        return {'SupplierID': CustomerID}
    except Exception as e:
        return {'error': str(e)}



def lambda_handler(event, context):
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = event.get('parameters', [])


    if function == 'create_recommendation':
        SupplierName = get_named_parameter(event, "SupplierName")
        Product_name = get_named_parameter(event, "Product_name")
        Reason_for_choice = get_named_parameter(event, "Reason_for_choice")
        

        if SupplierName and Product_name and Reason_for_choice:
            response = str(create_recommendation(SupplierName, Product_name, Reason_for_choice))
            responseBody = {'TEXT': {'body': json.dumps(response)}}
        else:
            responseBody = {'TEXT': {'body': 'Missing required parameters'}}
        else:
            responseBody = {'TEXT': {'body': 'Invalid function'}}


    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response
