import json
import uuid
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('recommendation_table')

def get_named_parameter(event, name):
    """
    Get a parameter from the lambda event
    """
    return next(item for item in event['parameters'] if item['name'] == name)['value']



def create_recommendation(CustomerName, CustomerEmail, recommendation):
    """
    Create a new recommendation entry
    
    Args:
        
        CustomerName (string):Name of the customer
        CustomerEmail (string): The email id of the particular customer
        recommendation (integer): The recommended product to that particular customer
    """
    try:
        CustomerID = str(uuid.uuid4())[:8]
        table.put_item(
            Item={
                'CustomerID': CustomerID,
                'CustomerName': CustomerName,
                'CustomerEmail': CustomerEmail,
                'recommendation': recommendation
            }
        )
        return {'CustomerID': CustomerID}
    except Exception as e:
        return {'error': str(e)}



def lambda_handler(event, context):
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = event.get('parameters', [])


    if function == 'create_recommendation':
        CustomerName = get_named_parameter(event, "CustomerName")
        CustomerEmail = get_named_parameter(event, "CustomerEmail")
        recommendation = get_named_parameter(event, "recommendation")
        

        if CustomerName and CustomerEmail and recommendation:
            response = str(create_recommendation(CustomerName, CustomerEmail, recommendation))
            responseBody = {'TEXT': {'body': json.dumps(response)}}
        else:
            responseBody = {'TEXT': {'body': 'Missing required parameters'}}
        else:
            responseBody = {'TEXT': {'body': 'Invalid function'}}


    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response
